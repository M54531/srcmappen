import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class CarApplication_2 {

    private final int delay = 10;

    CarView_2 frame=new CarView_2("Cars");
    CarModel_2 carModel=new CarModel_2();
    CarController_2 carControl=new CarController_2(frame,carModel);
    private Timer timer = new Timer(delay, new TimerListener());

    private class TimerListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {//action metoden, anropas av timer varje 10(delay)
            carModel.updatePos();
            frame.updateState(carModel.carImages,carModel.carPosition);
        }
    }

    public static void main(String[] args) {
        CarApplication_2 carapp = new CarApplication_2();
        Volvo240 minVolvo = new Volvo240();
        Scania minScania = new Scania();
        carapp.carModel.addCar(minVolvo);
        //carapp.carModel.addCar(minScania);
        //carapp.carModel.addScania()
        carapp.carModel.addSaab();
        carapp.carModel.addSaab();
        carapp.carModel.addSaab();
        //System.out.println(carapp.carModel.carImages.get(0));
        //System.out.println(carapp.carModel.carImages.get(1));
        System.out.println(carapp.carModel.carImages.size());
        carapp.timer.start();
    }
}
